"""
Canopy density rasterizer.

Generates a top-down density GeoTIFF from a LAS at full resolution
(no point downsampling). Output is cached on disk and reused on
subsequent runs.

Public API
----------
build_canopy_raster(
    las_manager, out_tif, resolution=0.05, height_cutoff=0.10,
    progress_cb=None, force=False)
    -> path to the GeoTIFF (created or reused)
"""

from __future__ import annotations
import os
import numpy as np


def build_canopy_raster(
    mgr,
    out_tif: str,
    resolution: float = 0.05,
    height_cutoff: float = 0.10,
    progress_cb=None,
    force: bool = False,
) -> str:
    """Build a 2D canopy density raster (.tif) from a loaded LAS.

    Parameters
    ----------
    mgr : LASManager  (already .load()ed)
    out_tif : str     output GeoTIFF path
    resolution : float    pixel size in metres (default 5 cm)
    height_cutoff : float threshold above ground for "canopy" points (when
        HAG is available); below this, points are treated as ground/noise
    force : bool      ignore cache, rebuild
    """
    def _p(pct, msg):
        if progress_cb: progress_cb(pct, msg)

    # --- cache check ---
    if not force and os.path.exists(out_tif):
        if os.path.getmtime(out_tif) >= os.path.getmtime(mgr.las_path):
            _p(100, "Using cached canopy raster")
            return out_tif

    import rasterio
    from rasterio.transform import from_origin

    _p(5, "Selecting canopy points...")
    x, y = mgr.x, mgr.y
    if mgr.hag is not None:
        # Use HAG to filter: keep only canopy points (above the cutoff)
        m = mgr.hag > height_cutoff
        x = x[m]; y = y[m]
        _p(15, f"Using {len(x):,} canopy points (HAG > {height_cutoff} m)")
    else:
        _p(15, f"Using all {len(x):,} points (no HAG available)")

    # --- raster grid ---
    xmin, xmax = float(x.min()), float(x.max())
    ymin, ymax = float(y.min()), float(y.max())
    nx = int(np.ceil((xmax - xmin) / resolution))
    ny = int(np.ceil((ymax - ymin) / resolution))
    _p(25, f"Rasterizing {nx} x {ny} pixels @ {resolution} m")

    # --- 2D histogram (point density per cell) ---
    H, _, _ = np.histogram2d(
        x, y, bins=[nx, ny],
        range=[[xmin, xmin + nx * resolution],
               [ymin, ymin + ny * resolution]]
    )
    _p(70, "Density computed; writing GeoTIFF...")

    # rasterio expects rows = north-down; histogram2d gives (nx, ny)
    # so transpose and flip Y
    density = H.T[::-1, :].astype("float32")

    transform = from_origin(xmin, ymin + ny * resolution, resolution, resolution)
    crs = str(mgr.crs) if mgr.crs else None

    with rasterio.open(
        out_tif, "w",
        driver="GTiff", height=ny, width=nx, count=1,
        dtype="float32", crs=crs, transform=transform,
        compress="lzw", tiled=True,
    ) as dst:
        dst.write(density, 1)

    _p(100, f"Wrote {out_tif}")
    return out_tif


def raster_display_array(tif_path: str, stretch_pct=(2, 99)) -> tuple:
    """Read a canopy GeoTIFF and return (display_uint8, bounds_tuple, crs).

    Stretches to 2..99 percentile by default for visualization.
    """
    import rasterio
    with rasterio.open(tif_path) as src:
        arr = src.read(1)
        b = src.bounds
        crs = src.crs

    nz = arr[arr > 0]
    if nz.size:
        vmin, vmax = np.percentile(nz, stretch_pct)
    else:
        vmin, vmax = float(arr.min()), float(arr.max() + 1)

    img = np.clip((arr - vmin) / max(vmax - vmin, 1e-9), 0, 1) * 255
    img = img.astype("uint8")
    return img, (b.left, b.bottom, b.right, b.top), crs
