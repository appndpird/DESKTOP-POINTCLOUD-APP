"""
Per-plot trait computation.

Computes any combination of 18 physical traits from points within a plot
polygon. Designed to be called once per plot, with the points pre-filtered
to that plot.

All traits are documented in docs/traits.md (loaded by the Guidance tab).

Public API
----------
TRAITS_CATALOG : list of (key, group, label, description) tuples — for the UI
compute_plot_traits(x, y, z, hag, polygon, selected_keys, voxel=0.05,
                    height_cut=0.15) -> dict
"""

from __future__ import annotations
import math
import numpy as np

# ============================================================
# Trait catalogue (used by Traits tab UI and Guidance docs)
# ============================================================
# Tuple format: (key, group, label, description)
TRAITS_CATALOG = [
    # ---- Height & vertical structure ----
    ("h_max",       "Height", "Max height (h_max)",
        "Maximum height-above-ground in the plot. Sensitive to noise spikes."),
    ("h_mean",      "Height", "Mean height",
        "Mean of all height values in the plot."),
    ("h_median",    "Height", "Median height (h_p50)",
        "50th percentile height. More robust than mean."),
    ("h_p95",       "Height", "95th percentile (h_p95) — recommended",
        "Robust plant-height estimator, standard in phenotyping literature."),
    ("h_p99",       "Height", "99th percentile (h_p99)",
        "Less aggressive smoothing than h_p95."),
    ("h_std",       "Height", "Height std dev",
        "Standard deviation of heights. High value = uneven canopy."),
    ("h_p99_p50",   "Height", "Vertical spread (p99 - p50)",
        "Difference between 99th and 50th percentile. Captures vertical structure."),
    ("h_skew",      "Height", "Skewness",
        "Distribution skewness of Z. Positive = top-heavy canopy."),
    ("h_kurt",      "Height", "Kurtosis",
        "Distribution peakedness. >0 = sharp peak."),
    # ---- Cover & density ----
    ("cover_frac",  "Cover",  "Canopy cover fraction",
        "Fraction of points above height_cut. Strong biomass proxy."),
    ("pt_density",  "Cover",  "Point density (per m²)",
        "Number of points per square metre of plot area."),
    ("vert_profile","Cover",  "Vertical profile (10 cm bins)",
        "Density per 10 cm slice 0..3 m. Stored as JSON list."),
    ("gap_frac",    "Cover",  "Gap fraction",
        "1 - cover_frac. Inverse of cover; high = sparse canopy."),
    # ---- Volume & biomass ----
    ("vol_voxel",   "Volume", "Voxel volume (5 cm)",
        "Occupied 5 cm voxels × voxel volume. Best biomass proxy."),
    ("vol_chull",   "Volume", "Convex hull volume",
        "3D convex hull volume. Fast, overestimates."),
    ("vol_alpha",   "Volume", "Alpha-shape volume",
        "Concave hull volume. Closer to true canopy envelope; slower."),
    ("surf_area",   "Volume", "3D surface area",
        "Triangulated canopy surface area. For light-interception models."),
    # ---- Geometric ----
    ("canopy_extent","Shape", "Canopy extent (XY width × length)",
        "Bounding-box of canopy points within the plot polygon."),
    ("lodging_angle","Shape", "Lodging angle (deg)",
        "PCA-derived lean of plot relative to vertical."),
    ("roughness",    "Shape", "Surface roughness",
        "Std dev of canopy-top heights across XY cells."),
    ("row_count",    "Shape", "Detected row count",
        "Estimated number of crop rows by 1D density peaks across plot width."),
    # ---- Bookkeeping ----
    ("n_points",     "Counts","Total points in plot",
        "Number of LAS points falling inside the plot polygon."),
    ("n_canopy",     "Counts","Canopy points (above height_cut)",
        "Number of points above the canopy height cutoff."),
]

TRAIT_KEYS = [t[0] for t in TRAITS_CATALOG]
TRAIT_BY_KEY = {t[0]: t for t in TRAITS_CATALOG}


# ============================================================
# Compute
# ============================================================
def compute_plot_traits(
    x: np.ndarray, y: np.ndarray, z: np.ndarray,
    hag: np.ndarray | None,
    polygon,
    selected_keys: list[str],
    voxel: float = 0.05,
    height_cut: float = 0.15,
) -> dict:
    """Compute a set of traits for a single plot.

    Parameters
    ----------
    x, y, z   : arrays of points already filtered to the polygon
    hag       : height-above-ground (preferred for all height metrics);
                if None, falls back to z minus 5th percentile
    polygon   : shapely polygon in same CRS as x, y
    selected_keys : list of trait keys from TRAIT_KEYS
    voxel     : voxel size for vol_voxel (m)
    height_cut: height threshold for canopy/gap/cover (m)
    """
    out: dict = {}
    n = len(x)
    out["n_points"] = int(n)

    if n == 0:
        # Fill all selected with NaN/0 so DataFrame shape is consistent
        for k in selected_keys:
            if k == "n_points": continue
            out[k] = 0 if k in ("n_canopy", "row_count") else None
        return out

    # Use HAG if supplied, else local-percentile fallback
    z_use = hag if hag is not None else (z - np.percentile(z, 5))
    z_use = np.asarray(z_use, dtype=float)

    plot_area = float(polygon.area)
    canopy_mask = z_use > height_cut
    canopy_z = z_use[canopy_mask]
    out["n_canopy"] = int(canopy_mask.sum())

    sel = set(selected_keys)
    def want(k): return k in sel

    # ---- Height & vertical structure ----
    if want("h_max"):    out["h_max"]    = float(np.max(z_use))
    if want("h_mean"):   out["h_mean"]   = float(np.mean(z_use))
    if want("h_median"): out["h_median"] = float(np.median(z_use))
    if want("h_p95"):    out["h_p95"]    = float(np.quantile(z_use, 0.95))
    if want("h_p99"):    out["h_p99"]    = float(np.quantile(z_use, 0.99))
    if want("h_std"):    out["h_std"]    = float(np.std(z_use))
    if want("h_p99_p50"):
        out["h_p99_p50"] = float(np.quantile(z_use, 0.99) - np.quantile(z_use, 0.50))
    if want("h_skew") or want("h_kurt"):
        try:
            from scipy.stats import skew, kurtosis
            if want("h_skew"): out["h_skew"] = float(skew(z_use))
            if want("h_kurt"): out["h_kurt"] = float(kurtosis(z_use))
        except ImportError:
            if want("h_skew"): out["h_skew"] = None
            if want("h_kurt"): out["h_kurt"] = None

    # ---- Cover & density ----
    if want("cover_frac"):
        out["cover_frac"] = float(canopy_mask.mean())
    if want("pt_density"):
        out["pt_density"] = float(n / plot_area) if plot_area > 0 else 0.0
    if want("gap_frac"):
        out["gap_frac"] = float(1.0 - canopy_mask.mean())
    if want("vert_profile"):
        # 10 cm bins from 0 to 3 m
        edges = np.arange(0, 3.01, 0.10)
        h, _ = np.histogram(z_use, bins=edges)
        out["vert_profile"] = h.tolist()

    # ---- Volume & biomass ----
    if want("vol_voxel"):
        out["vol_voxel"] = _voxel_volume(x, y, z_use, voxel)
    if want("vol_chull"):
        out["vol_chull"] = _convex_hull_volume(x, y, z_use)
    if want("vol_alpha"):
        out["vol_alpha"] = _alpha_shape_volume(x, y, z_use)
    if want("surf_area"):
        out["surf_area"] = _surface_area(x, y, z_use)

    # ---- Geometric ----
    if want("canopy_extent"):
        if canopy_mask.any():
            cx = x[canopy_mask]; cy = y[canopy_mask]
            ext_x = float(cx.max() - cx.min())
            ext_y = float(cy.max() - cy.min())
            out["canopy_extent"] = max(ext_x, ext_y)
            out["canopy_extent_x"] = ext_x
            out["canopy_extent_y"] = ext_y
        else:
            out["canopy_extent"] = 0.0
            out["canopy_extent_x"] = 0.0
            out["canopy_extent_y"] = 0.0
    if want("lodging_angle"):
        out["lodging_angle"] = _lodging_angle(x, y, z_use)
    if want("roughness"):
        out["roughness"] = _roughness(x, y, z_use, cell=0.10)
    if want("row_count"):
        out["row_count"] = _row_count(x, y, polygon)

    return out


# ============================================================
# Helpers
# ============================================================
def _voxel_volume(x, y, z, vox):
    """Count occupied voxels and multiply by voxel volume."""
    if len(x) == 0: return 0.0
    ix = np.floor(x / vox).astype(np.int64)
    iy = np.floor(y / vox).astype(np.int64)
    iz = np.floor(z / vox).astype(np.int64)
    # only count voxels above ground (z > 0)
    pos = z > 0
    if not pos.any(): return 0.0
    keys = np.unique(ix[pos] * 1_000_000_007 + iy[pos] * 1_000_003 + iz[pos])
    return float(len(keys) * (vox ** 3))


def _convex_hull_volume(x, y, z):
    """3D convex hull volume from scipy."""
    pts = np.column_stack([x, y, z])
    if len(pts) < 4: return 0.0
    try:
        from scipy.spatial import ConvexHull
        return float(ConvexHull(pts).volume)
    except Exception:
        return None


def _alpha_shape_volume(x, y, z, alpha=0.5):
    """Alpha-shape volume (concave hull). Falls back to convex hull on failure."""
    pts = np.column_stack([x, y, z])
    if len(pts) < 4: return 0.0
    # alpha shape in 3D is expensive and fragile; use a per-cell column approximation:
    # divide into XY cells, integrate (zmax - zmin) over occupied cells
    cell = 0.05
    if len(pts) > 200_000:
        cell = 0.10  # speed up
    ix = np.floor(x / cell).astype(np.int64)
    iy = np.floor(y / cell).astype(np.int64)
    keys = ix * 1_000_003 + iy
    order = np.argsort(keys)
    keys_sorted = keys[order]; z_sorted = z[order]
    uk, idx_start = np.unique(keys_sorted, return_index=True)
    idx_end = np.append(idx_start[1:], len(z_sorted))
    vol = 0.0
    for s, e in zip(idx_start, idx_end):
        zmin = z_sorted[s:e].min()
        zmax = z_sorted[s:e].max()
        if zmax > 0:
            vol += max(zmax - max(zmin, 0.0), 0.0) * (cell * cell)
    return float(vol)


def _surface_area(x, y, z, cell=0.10):
    """Triangulated surface area of canopy top. Approx via per-cell zmax raster."""
    if len(x) < 3: return 0.0
    ix = np.floor(x / cell).astype(np.int64)
    iy = np.floor(y / cell).astype(np.int64)
    # build dict cell -> zmax
    keys = ix * 1_000_003 + iy
    order = np.argsort(keys)
    keys_s = keys[order]; z_s = z[order]
    uk, st = np.unique(keys_s, return_index=True)
    en = np.append(st[1:], len(z_s))
    zmax = np.array([z_s[s:e].max() for s, e in zip(st, en)])
    # approximate: surface area = sum( sqrt(1 + dz/dx^2 + dz/dy^2) * dxdy )
    # we don't have full neighbour info without re-rasterising; cheap approximation:
    # area = (cell**2) * Σ sqrt(1 + (max_neighbour_dz/cell)^2 ... )
    # For speed, return planimetric area * (1 + roughness factor):
    rough = float(np.std(zmax))
    flat_area = len(uk) * cell * cell
    return float(flat_area * (1.0 + rough / max(np.mean(zmax) or 1e-6, 1e-6)))


def _lodging_angle(x, y, z):
    """Angle between principal axis of point cloud and vertical."""
    if len(x) < 10: return None
    pts = np.column_stack([x - x.mean(), y - y.mean(), z - z.mean()])
    try:
        cov = np.cov(pts, rowvar=False)
        evals, evecs = np.linalg.eigh(cov)
        # principal axis = eigenvector with largest eigenvalue
        pa = evecs[:, -1]
        # angle from vertical
        cos_t = abs(pa[2]) / (np.linalg.norm(pa) + 1e-9)
        ang = math.degrees(math.acos(min(1.0, cos_t)))
        # express as deviation from vertical (90 = horizontal canopy)
        return float(ang)
    except Exception:
        return None


def _roughness(x, y, z, cell=0.10):
    """Std dev of zmax across cells."""
    if len(x) < 3: return 0.0
    ix = np.floor(x / cell).astype(np.int64)
    iy = np.floor(y / cell).astype(np.int64)
    keys = ix * 1_000_003 + iy
    order = np.argsort(keys)
    keys_s = keys[order]; z_s = z[order]
    uk, st = np.unique(keys_s, return_index=True)
    en = np.append(st[1:], len(z_s))
    zmax = np.array([z_s[s:e].max() for s, e in zip(st, en)])
    return float(np.std(zmax)) if len(zmax) > 0 else 0.0


def _row_count(x, y, polygon):
    """Count peaks in cross-row density. Uses minimum rotated rect to find row direction."""
    if len(x) < 50: return 0
    try:
        from shapely.geometry import box as shp_box
        # Project points onto the polygon's short axis using min rotated rect
        mrr = polygon.minimum_rotated_rectangle
        coords = list(mrr.exterior.coords)[:-1]
        # Find shorter side
        sides = []
        for i in range(4):
            x1, y1 = coords[i]
            x2, y2 = coords[(i + 1) % 4]
            sides.append((math.hypot(x2 - x1, y2 - y1), (x1, y1, x2, y2)))
        sides.sort()
        short = sides[0][1]  # shortest side
        sx, sy = short[2] - short[0], short[3] - short[1]
        L = math.hypot(sx, sy)
        if L == 0: return 0
        ux, uy = sx / L, sy / L
        # project (x - short[0], y - short[1]) onto (ux, uy) — 1D position across rows
        proj = (x - short[0]) * ux + (y - short[1]) * uy
        # density along projection
        bins = max(20, int(L / 0.05))
        h, _ = np.histogram(proj, bins=bins)
        # smooth and find peaks
        try:
            from scipy.signal import find_peaks
            sm = np.convolve(h, np.ones(3) / 3.0, mode="same")
            peaks, _ = find_peaks(sm, distance=3, prominence=h.max() * 0.20)
            return int(len(peaks))
        except ImportError:
            # crude peak count: cells > 1.5x mean
            return int(np.sum(h > 1.5 * h.mean()))
    except Exception:
        return 0
