"""Core engine for the phenotyping app — UI-agnostic."""
from .las_manager   import LASManager, quick_summary
from .canopy_raster import build_canopy_raster, raster_display_array
from .grid_io       import load_grid, save_grid, detect_format, GRID_FILE_FILTER
from .grid_gen      import generate_grid_from_corners
from .traits        import TRAITS_CATALOG, TRAIT_KEYS, TRAIT_BY_KEY, compute_plot_traits
from .extract       import extract_all_plots
