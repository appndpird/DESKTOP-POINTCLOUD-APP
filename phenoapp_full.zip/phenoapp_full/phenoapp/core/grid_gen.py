"""
Grid generation from 4 corners + plot dimensions + buffers.

Given:
  - 4 corner points of the trial (in working CRS coordinates), in order
    bottom-left, bottom-right, top-right, top-left
  - n_banks (rows of plots — wide alleys between banks)
  - n_rows  (plots per bank — narrow gaps between plots)
  - plot_w, plot_l (planted area per plot, m)
  - gap_row, gap_bank (m)

Build a regular plot grid that fills the trial extent.

Public API
----------
generate_grid_from_corners(corners, n_banks, n_rows,
                           plot_w, plot_l, gap_row, gap_bank,
                           crs) -> GeoDataFrame
"""

from __future__ import annotations
import math
import numpy as np
import geopandas as gpd
from shapely.geometry import Polygon
from shapely.affinity import rotate, translate


def generate_grid_from_corners(
    corners: list[tuple[float, float]],
    n_banks: int,
    n_rows: int,
    plot_w: float,
    plot_l: float,
    gap_row: float,
    gap_bank: float,
    crs: str,
) -> gpd.GeoDataFrame:
    if len(corners) != 4:
        raise ValueError("Need exactly 4 corners (BL, BR, TR, TL)")

    bl, br, tr, tl = [np.asarray(c, dtype=float) for c in corners]

    # Determine the orientation from the bottom edge BL -> BR (row direction)
    row_vec = br - bl
    row_len = np.linalg.norm(row_vec)
    if row_len == 0:
        raise ValueError("BL and BR are the same point")
    ux = row_vec / row_len   # unit along row direction
    # Bank direction = BL -> TL
    bank_vec = tl - bl
    bank_len = np.linalg.norm(bank_vec)
    if bank_len == 0:
        raise ValueError("BL and TL are the same point")
    uy = bank_vec / bank_len   # unit along bank direction

    # Build axis-aligned grid centred at (0, 0), oriented so row_dir = +X, bank_dir = +Y
    polys, attrs = [], []
    for b in range(n_banks):
        for r in range(n_rows):
            x0 = r * (plot_w + gap_row)
            y0 = b * (plot_l + gap_bank)
            poly = Polygon([
                (x0,           y0),
                (x0 + plot_w,  y0),
                (x0 + plot_w,  y0 + plot_l),
                (x0,           y0 + plot_l),
            ])
            polys.append(poly)
            attrs.append({
                "Plot_ID": (b + 1) * 1000 + (r + 1),
                "B/R":     f"B{b+1}R{r+1}",
                "Bank":    b + 1,
                "Row":     r + 1,
            })

    gdf = gpd.GeoDataFrame(attrs, geometry=polys, crs=crs)

    # Rotate from local +X axis to ux direction
    angle = math.degrees(math.atan2(ux[1], ux[0]))
    gdf["geometry"] = gdf.geometry.apply(lambda g: rotate(g, angle, origin=(0, 0)))

    # Translate so that plot (1,1) BL is at the user's BL corner
    gdf["geometry"] = gdf.geometry.apply(lambda g: translate(g, bl[0], bl[1]))

    return gdf
