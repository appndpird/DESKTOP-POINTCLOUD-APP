"""
Edit tab: align plot polygons over the canopy raster.

Click/drag to move; rubber-band for multi-select; toolbar/keyboard for
rotate, scale, undo, save.
"""

from __future__ import annotations
import os
from PyQt5.QtCore import Qt, QPointF, QRectF, pyqtSignal
from PyQt5.QtGui import QPen, QBrush, QColor, QKeySequence, QPolygonF
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QToolBar,
    QShortcut, QMessageBox, QAction, QRubberBand, QGraphicsItem,
    QGraphicsPolygonItem, QSizePolicy
)
from shapely.affinity import (
    rotate as sh_rotate, translate as sh_translate, scale as sh_scale
)
from shapely.ops import unary_union
import geopandas as gpd

from phenoapp.core.project import state
from phenoapp.core import load_grid, save_grid
from phenoapp.ui.canopy_view import CanopyView, shp_to_qpoly, qpoly_to_shp


class PlotItem(QGraphicsPolygonItem):
    def __init__(self, plot_idx, shp_poly):
        super().__init__(shp_to_qpoly(shp_poly))
        self.plot_idx = plot_idx
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self._refresh_style()

    def _refresh_style(self):
        if self.isSelected():
            self.setPen(QPen(QColor(255, 220, 0), 0.10))
            self.setBrush(QBrush(QColor(255, 220, 0, 70)))
        else:
            self.setPen(QPen(QColor(255, 60, 60), 0.07))
            self.setBrush(QBrush(QColor(255, 0, 0, 0)))

    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemSelectedHasChanged:
            self._refresh_style()
        return super().itemChange(change, value)

    def shapely(self):
        return qpoly_to_shp(self.polygon())


class EditView(CanopyView):
    """Subclass that adds rubber-band selection, click-select, and drag-move."""
    def __init__(self, owner_tab):
        super().__init__()
        self._owner = owner_tab
        self._move_anchor = None
        self._move_origins = None
        self._rubber = None
        self._rubber_start_view = None
        self._move_active = False

    def mousePressEvent(self, event):
        # Pan via middle-click or Ctrl+left -> base class
        if event.button() == Qt.MiddleButton or \
           (event.button() == Qt.LeftButton and (event.modifiers() & Qt.ControlModifier)):
            return super().mousePressEvent(event)

        if event.button() == Qt.LeftButton:
            scene_pos = self.mapToScene(event.pos())
            mods = event.modifiers()
            item = self._plot_at(scene_pos)
            if item is not None:
                shift = bool(mods & Qt.ShiftModifier)
                if shift:
                    item.setSelected(not item.isSelected())
                else:
                    if not item.isSelected():
                        self.scene().clearSelection()
                        item.setSelected(True)
                self._move_anchor = scene_pos
                self._move_origins = {it: it.polygon()
                                      for it in self.scene().selectedItems()
                                      if isinstance(it, PlotItem)}
                self._move_active = True
                event.accept()
                return
            else:
                if not (mods & Qt.ShiftModifier):
                    self.scene().clearSelection()
                self._rubber_start_view = event.pos()
                self._rubber = QRubberBand(QRubberBand.Rectangle, self)
                self._rubber.setGeometry(0, 0, 0, 0)
                self._rubber.show()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        scene_pos = self.mapToScene(event.pos())
        wx, wy = scene_pos.x(), -scene_pos.y()
        self.coords_changed.emit(wx, wy)
        if self._move_active and self._move_anchor is not None:
            dx = scene_pos.x() - self._move_anchor.x()
            dy = scene_pos.y() - self._move_anchor.y()
            for item, orig in self._move_origins.items():
                item.setPolygon(QPolygonF(
                    [QPointF(p.x() + dx, p.y() + dy) for p in orig]))
            event.accept()
            return
        if self._rubber is not None:
            r = QRectF(self._rubber_start_view, event.pos()).normalized().toRect()
            self._rubber.setGeometry(r)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._move_active:
            scene_pos = self.mapToScene(event.pos())
            moved = (abs(scene_pos.x() - self._move_anchor.x()) > 1e-3 or
                     abs(scene_pos.y() - self._move_anchor.y()) > 1e-3)
            self._move_anchor = None
            self._move_origins = None
            self._move_active = False
            if moved:
                self._owner.push_undo()
            event.accept()
            return
        if self._rubber is not None:
            r = self._rubber.geometry()
            scene_rect = self.mapToScene(r).boundingRect()
            for it in self.scene().items(scene_rect):
                if isinstance(it, PlotItem):
                    it.setSelected(True)
            self._rubber.hide()
            self._rubber.deleteLater()
            self._rubber = None
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def _plot_at(self, scene_pos):
        for it in self.scene().items(scene_pos):
            if isinstance(it, PlotItem):
                return it
        return None


class EditTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._undo_stack = []
        self._original_geoms = []
        self._grid_attrs = None
        self._grid_crs = None
        self._build_ui()

    def _build_ui(self):
        v = QVBoxLayout(self)

        tb = QToolBar()
        tb.addAction("Reload from Project", self.reload_grid_and_canopy)
        tb.addSeparator()
        tb.addAction("Select All",  self.select_all)
        tb.addAction("Deselect",    self.deselect_all)
        tb.addSeparator()
        tb.addAction("Rot -1°",   lambda: self.rotate_sel(-1))
        tb.addAction("Rot +1°",   lambda: self.rotate_sel(+1))
        tb.addAction("Rot -0.1°", lambda: self.rotate_sel(-0.1))
        tb.addAction("Rot +0.1°", lambda: self.rotate_sel(+0.1))
        tb.addAction("Scale +1%", lambda: self.scale_sel(1.01))
        tb.addAction("Scale -1%", lambda: self.scale_sel(0.99))
        tb.addSeparator()
        tb.addAction("Undo (Z)",  self.undo)
        tb.addAction("Reset",     self.reset)
        tb.addSeparator()
        tb.addAction("Fit View",  self.fit_view)
        tb.addAction("💾 Save Grid", self.save_grid)
        v.addWidget(tb)

        self.view = EditView(self)
        self.view.coords_changed.connect(self._on_coords)
        self.view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        v.addWidget(self.view, stretch=1)

        bar = QHBoxLayout()
        self.lbl_coords = QLabel("E --, N --")
        self.lbl_sel    = QLabel("Selected: 0")
        self.lbl_status = QLabel("Load project then click Reload from Project.")
        bar.addWidget(self.lbl_coords)
        bar.addWidget(self.lbl_sel)
        bar.addStretch()
        bar.addWidget(self.lbl_status)
        v.addLayout(bar)

        # keyboard shortcuts
        for k, fn in [
            ("A", self.select_all), ("D", self.deselect_all),
            ("Z", self.undo), ("S", self.save_grid),
            ("Q",       lambda: self.rotate_sel(-1)),
            ("E",       lambda: self.rotate_sel(+1)),
            ("Shift+Q", lambda: self.rotate_sel(-5)),
            ("Shift+E", lambda: self.rotate_sel(+5)),
            ("Left",        lambda: self.translate_sel(-0.1, 0)),
            ("Right",       lambda: self.translate_sel(+0.1, 0)),
            ("Up",          lambda: self.translate_sel(0, +0.1)),
            ("Down",        lambda: self.translate_sel(0, -0.1)),
            ("Shift+Left",  lambda: self.translate_sel(-1.0, 0)),
            ("Shift+Right", lambda: self.translate_sel(+1.0, 0)),
            ("Shift+Up",    lambda: self.translate_sel(0, +1.0)),
            ("Shift+Down",  lambda: self.translate_sel(0, -1.0)),
            ("+", lambda: self.scale_sel(1.01)),
            ("=", lambda: self.scale_sel(1.01)),
            ("-", lambda: self.scale_sel(0.99)),
        ]:
            QShortcut(QKeySequence(k), self, fn)

        self.view.scene().selectionChanged.connect(self._on_sel_changed)

    # ---------- public ----------
    def reload_grid_and_canopy(self):
        s = state()
        if s.canopy_tif and os.path.exists(s.canopy_tif):
            self.view.load_canopy_raster(s.canopy_tif)
        if s.grid_path and os.path.exists(s.grid_path):
            self._load_grid(s.grid_path)
        elif s.saved_grid and os.path.exists(s.saved_grid):
            self._load_grid(s.saved_grid)
        self.view.fit_view()

    # ---------- grid loading ----------
    def _load_grid(self, path):
        gdf = load_grid(path, target_crs=state().work_crs)
        self._grid_attrs = gdf.drop(columns="geometry").reset_index(drop=True)
        self._grid_crs = gdf.crs
        self._original_geoms = list(gdf.geometry)
        # remove existing PlotItems
        for it in list(self.view.scene().items()):
            if isinstance(it, PlotItem):
                self.view.scene().removeItem(it)
        for i, g in enumerate(gdf.geometry):
            self.view.scene().addItem(PlotItem(i, g))
        self.lbl_status.setText(f"Loaded {len(gdf)} plots from {os.path.basename(path)}")

    # ---------- helpers ----------
    def _all_plots(self):
        return [it for it in self.view.scene().items() if isinstance(it, PlotItem)]
    def _sel(self):
        return [it for it in self.view.scene().selectedItems() if isinstance(it, PlotItem)]

    def push_undo(self):
        snap = [(it.plot_idx, it.shapely()) for it in self._all_plots()]
        self._undo_stack.append(snap)
        if len(self._undo_stack) > 30:
            self._undo_stack.pop(0)

    # ---------- actions ----------
    def select_all(self):
        for it in self._all_plots(): it.setSelected(True)
    def deselect_all(self):
        self.view.scene().clearSelection()

    def undo(self):
        if not self._undo_stack: return
        snap = self._undo_stack.pop()
        by = {it.plot_idx: it for it in self._all_plots()}
        for idx, geom in snap:
            it = by.get(idx)
            if it: it.setPolygon(shp_to_qpoly(geom))

    def reset(self):
        if not self._original_geoms: return
        self.push_undo()
        by = {it.plot_idx: it for it in self._all_plots()}
        for i, g in enumerate(self._original_geoms):
            it = by.get(i)
            if it: it.setPolygon(shp_to_qpoly(g))

    def fit_view(self):
        self.view.fit_view()

    def translate_sel(self, dx, dy):
        sel = self._sel()
        if not sel: return
        self.push_undo()
        for it in sel:
            it.setPolygon(shp_to_qpoly(sh_translate(it.shapely(), dx, dy)))

    def rotate_sel(self, deg):
        sel = self._sel()
        if not sel: return
        self.push_undo()
        u = unary_union([it.shapely() for it in sel])
        cx, cy = u.centroid.x, u.centroid.y
        for it in sel:
            it.setPolygon(shp_to_qpoly(sh_rotate(it.shapely(), deg, origin=(cx, cy))))

    def scale_sel(self, f):
        sel = self._sel()
        if not sel: return
        self.push_undo()
        u = unary_union([it.shapely() for it in sel])
        cx, cy = u.centroid.x, u.centroid.y
        for it in sel:
            it.setPolygon(shp_to_qpoly(
                sh_scale(it.shapely(), xfact=f, yfact=f, origin=(cx, cy))))

    def save_grid(self):
        if not self._grid_attrs is not None or not self._all_plots():
            QMessageBox.warning(self, "Nothing to save", "Load a grid first.")
            return
        s = state()
        out_path = s.saved_grid or os.path.join(
            os.path.dirname(s.las_path or "."), "aligned_grid.gpkg")
        plots = sorted(self._all_plots(), key=lambda it: it.plot_idx)
        out = self._grid_attrs.copy()
        out["geometry"] = [it.shapely() for it in plots]
        gdf = gpd.GeoDataFrame(out, geometry="geometry", crs=self._grid_crs)
        save_grid(gdf, out_path)
        s.saved_grid = out_path
        self.lbl_status.setText(f"Saved → {out_path}")

    # ---------- callbacks ----------
    def _on_coords(self, wx, wy):
        self.lbl_coords.setText(f"E {wx:.2f}  N {wy:.2f}")
    def _on_sel_changed(self):
        n = sum(1 for it in self.view.scene().selectedItems() if isinstance(it, PlotItem))
        self.lbl_sel.setText(f"Selected: {n}")
