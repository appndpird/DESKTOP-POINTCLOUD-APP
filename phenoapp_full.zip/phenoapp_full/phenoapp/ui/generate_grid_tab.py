"""
Generate Grid tab: click 4 corners on the canopy, set parameters, save.
"""

from __future__ import annotations
import os
from PyQt5.QtCore import Qt, QPointF
from PyQt5.QtGui import QPen, QBrush, QColor
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QPushButton,
    QSpinBox, QDoubleSpinBox, QGroupBox, QFileDialog, QMessageBox,
    QToolBar, QSizePolicy
)

from phenoapp.core.project import state
from phenoapp.core import generate_grid_from_corners, save_grid
from phenoapp.ui.canopy_view import CanopyView, world_to_scene


class GenerateGridTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._corners = []         # list of (wx, wy) — picked points
        self._corner_dots = []     # graphics items for visualisation
        self._preview_items = []   # preview polygons
        self._build_ui()

    def _build_ui(self):
        v = QVBoxLayout(self)

        # ---- top: instructions + corner state ----
        v.addWidget(QLabel(
            "<b>Click the 4 corners of the trial</b> in this order: "
            "BL → BR → TR → TL (counter-clockwise from bottom-left).  "
            "Then set the trial layout below and click <b>Preview Grid</b>."))

        # ---- toolbar ----
        tb = QToolBar()
        tb.addAction("Reload Canopy",   self.reload_canopy)
        tb.addAction("Clear Corners",   self.clear_corners)
        tb.addAction("Fit View",        self._fit_view)
        v.addWidget(tb)

        # ---- canvas ----
        self.view = CanopyView()
        self.view.coords_changed.connect(self._on_coords)
        self.view.left_press.connect(self._on_left_click)
        self.view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        v.addWidget(self.view, stretch=1)

        # ---- parameters ----
        params = QGroupBox("Trial layout")
        f = QFormLayout(params)

        self.sb_banks = QSpinBox(); self.sb_banks.setRange(1, 999); self.sb_banks.setValue(4)
        self.sb_rows  = QSpinBox(); self.sb_rows.setRange(1, 9999); self.sb_rows.setValue(32)
        self.dsb_pw   = QDoubleSpinBox(); self.dsb_pw.setRange(0.05, 50); self.dsb_pw.setValue(1.5); self.dsb_pw.setSuffix(" m")
        self.dsb_pl   = QDoubleSpinBox(); self.dsb_pl.setRange(0.05, 50); self.dsb_pl.setValue(6.0); self.dsb_pl.setSuffix(" m")
        self.dsb_gr   = QDoubleSpinBox(); self.dsb_gr.setRange(0, 50); self.dsb_gr.setValue(0.5); self.dsb_gr.setSuffix(" m")
        self.dsb_gb   = QDoubleSpinBox(); self.dsb_gb.setRange(0, 50); self.dsb_gb.setValue(2.0); self.dsb_gb.setSuffix(" m")
        f.addRow("Number of banks:",  self.sb_banks)
        f.addRow("Plots per bank (rows):", self.sb_rows)
        f.addRow("Plot width:",       self.dsb_pw)
        f.addRow("Plot length:",      self.dsb_pl)
        f.addRow("Gap between rows:", self.dsb_gr)
        f.addRow("Gap between banks:",self.dsb_gb)
        v.addWidget(params)

        # ---- buttons ----
        h = QHBoxLayout()
        self.btn_preview = QPushButton("👁️ Preview Grid")
        self.btn_preview.clicked.connect(self.preview)
        self.btn_save    = QPushButton("💾 Save Grid")
        self.btn_save.clicked.connect(self.save)
        self.lbl_status  = QLabel("Click 0/4 corners.")
        h.addWidget(self.btn_preview)
        h.addWidget(self.btn_save)
        h.addStretch()
        h.addWidget(self.lbl_status)
        v.addLayout(h)

    # ---- canopy ----
    def reload_canopy(self):
        s = state()
        if s.canopy_tif and os.path.exists(s.canopy_tif):
            self.view.load_canopy_raster(s.canopy_tif)

    def _fit_view(self):
        self.view.fit_view()

    # ---- corner picking ----
    def _on_left_click(self, scene_pos):
        if len(self._corners) >= 4:
            return
        wx, wy = scene_pos.x(), -scene_pos.y()
        self._corners.append((wx, wy))
        # draw a dot
        r = 0.4   # 40 cm marker
        dot = self.view.scene().addEllipse(
            scene_pos.x() - r, scene_pos.y() - r, 2 * r, 2 * r,
            QPen(QColor("yellow"), 0.05), QBrush(QColor("yellow")))
        # label
        labels = ["BL", "BR", "TR", "TL"]
        txt = self.view.scene().addText(labels[len(self._corners) - 1])
        txt.setPos(scene_pos.x() + r, scene_pos.y() - r)
        txt.setDefaultTextColor(QColor("yellow"))
        self._corner_dots += [dot, txt]
        self.lbl_status.setText(f"Click {len(self._corners)}/4 corners.")

    def clear_corners(self):
        self._corners = []
        for it in self._corner_dots:
            self.view.scene().removeItem(it)
        self._corner_dots = []
        self._clear_preview()
        self.lbl_status.setText("Click 0/4 corners.")

    def _clear_preview(self):
        for it in self._preview_items:
            self.view.scene().removeItem(it)
        self._preview_items = []

    # ---- preview / save ----
    def _build_grid(self):
        if len(self._corners) != 4:
            raise RuntimeError("Need 4 corners")
        return generate_grid_from_corners(
            self._corners,
            self.sb_banks.value(),
            self.sb_rows.value(),
            self.dsb_pw.value(),
            self.dsb_pl.value(),
            self.dsb_gr.value(),
            self.dsb_gb.value(),
            crs=state().work_crs,
        )

    def preview(self):
        if len(self._corners) != 4:
            QMessageBox.warning(self, "Need 4 corners",
                "Click all 4 corners (BL, BR, TR, TL) on the canopy first.")
            return
        try:
            gdf = self._build_grid()
        except Exception as e:
            QMessageBox.critical(self, "Build failed", str(e))
            return
        self._clear_preview()
        for poly in gdf.geometry:
            from phenoapp.ui.canopy_view import shp_to_qpoly
            from PyQt5.QtWidgets import QGraphicsPolygonItem
            it = QGraphicsPolygonItem(shp_to_qpoly(poly))
            it.setPen(QPen(QColor(80, 200, 255), 0.07))
            it.setBrush(QBrush(QColor(80, 200, 255, 40)))
            self.view.scene().addItem(it)
            self._preview_items.append(it)
        self.lbl_status.setText(f"Preview: {len(gdf)} plots.")

    def save(self):
        if len(self._corners) != 4:
            QMessageBox.warning(self, "Need 4 corners", "Click all 4 corners first.")
            return
        try:
            gdf = self._build_grid()
        except Exception as e:
            QMessageBox.critical(self, "Build failed", str(e))
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save grid",
            os.path.join(os.path.dirname(state().las_path or "."), "generated_grid.gpkg"),
            "GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson);;All files (*)")
        if not path:
            return
        try:
            save_grid(gdf, path)
            state().grid_path = path
            self.lbl_status.setText(f"Saved → {path}")
            QMessageBox.information(self, "Saved",
                f"Grid saved to:\n{path}\n\nGo to the Project tab and reload, "
                "or switch to the Edit tab and click 'Reload from Project' to align it.")
        except Exception as e:
            QMessageBox.critical(self, "Save failed", str(e))

    def _on_coords(self, wx, wy):
        self.lbl_status.setText(
            f"Cursor: E {wx:.2f}  N {wy:.2f}   |   Corners clicked: {len(self._corners)}/4")
