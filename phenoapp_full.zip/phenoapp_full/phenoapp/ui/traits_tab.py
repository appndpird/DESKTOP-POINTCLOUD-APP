"""
Traits tab: choose physical traits to compute, run extraction, save CSV.
"""

from __future__ import annotations
import os
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QCheckBox, QPushButton,
    QLabel, QProgressBar, QFileDialog, QMessageBox, QFormLayout,
    QDoubleSpinBox, QGridLayout, QScrollArea, QTextEdit, QSizePolicy
)

from phenoapp.core.project import state
from phenoapp.core import (
    LASManager, load_grid, extract_all_plots,
    TRAITS_CATALOG, TRAIT_KEYS,
)


class _ExtractWorker(QThread):
    progress = pyqtSignal(int, str)
    done_ok  = pyqtSignal(dict)
    error    = pyqtSignal(str)

    def __init__(self, kwargs):
        super().__init__()
        self._kw = kwargs
        self._cancel = False

    def cancel(self): self._cancel = True

    def run(self):
        try:
            kw = self._kw
            mgr = LASManager(kw["las_path"], kw["work_crs"], kw["use_smrf"])
            self.progress.emit(2, "Loading LAS...")
            def cb(p, m): self.progress.emit(int(2 + p * 0.18), m)
            mgr.load(progress_cb=cb)

            self.progress.emit(20, "Loading grid...")
            plots = load_grid(kw["grid_path"], target_crs=kw["work_crs"])
            self.progress.emit(25, f"{len(plots)} plots ready")

            def pcb(p, m):
                self.progress.emit(int(25 + p * 0.74), m)

            df = extract_all_plots(
                mgr, plots,
                out_dir=kw["out_dir"], out_csv=kw["out_csv"],
                selected_traits=kw["selected"],
                write_las=kw["write_las"],
                height_cut=kw["h_cut"], voxel=kw["vox"],
                progress_cb=pcb, cancel_flag=lambda: self._cancel,
            )
            self.progress.emit(100, "Done")

            empty = int((df["n_points"] == 0).sum()) if "n_points" in df else 0
            non = int(len(df) - empty)
            med = 0
            if non:
                med = int(df.loc[df["n_points"] > 0, "n_points"].median())
            self.done_ok.emit({"non": non, "empty": empty, "total": len(df),
                               "median_pts": med, "out_csv": kw["out_csv"],
                               "out_dir": kw["out_dir"]})
        except Exception as e:
            import traceback
            self.error.emit(f"{e}\n\n{traceback.format_exc()}")


class TraitsTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._checks = {}      # key -> QCheckBox
        self._build_ui()

    def _build_ui(self):
        v = QVBoxLayout(self)
        v.addWidget(QLabel("<h2>Compute physical traits per plot</h2>"))
        v.addWidget(QLabel(
            "Pick which traits you want. Recommended defaults are pre-selected. "
            "See the Guidance tab for trait definitions and methods."))

        # ---- Trait selection ----
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        inner = QWidget(); scroll.setWidget(inner)
        gl = QGridLayout(inner)

        # Group by category
        by_group = {}
        for key, group, label, desc in TRAITS_CATALOG:
            by_group.setdefault(group, []).append((key, label, desc))

        # Recommended defaults
        defaults = {"h_p95", "h_p99", "h_mean", "h_std", "cover_frac",
                    "vol_voxel", "lodging_angle", "roughness",
                    "n_points", "n_canopy"}

        col = 0
        for group, items in by_group.items():
            box = QGroupBox(group)
            f = QVBoxLayout(box)
            for key, label, desc in items:
                cb = QCheckBox(label)
                cb.setToolTip(desc)
                if key in defaults:
                    cb.setChecked(True)
                self._checks[key] = cb
                f.addWidget(cb)
            f.addStretch()
            gl.addWidget(box, 0, col)
            col += 1
        v.addWidget(scroll, stretch=1)

        # ---- Quick selectors ----
        h = QHBoxLayout()
        b1 = QPushButton("Select All");          b1.clicked.connect(self._sel_all)
        b2 = QPushButton("Recommended Defaults"); b2.clicked.connect(self._defaults)
        b3 = QPushButton("Deselect All");        b3.clicked.connect(self._desel_all)
        h.addWidget(b1); h.addWidget(b2); h.addWidget(b3); h.addStretch()
        v.addLayout(h)

        # ---- Parameters ----
        params = QGroupBox("Parameters")
        f = QFormLayout(params)
        self.dsb_hcut = QDoubleSpinBox(); self.dsb_hcut.setRange(0.0, 5.0); self.dsb_hcut.setValue(0.15); self.dsb_hcut.setSuffix(" m")
        self.dsb_vox  = QDoubleSpinBox(); self.dsb_vox.setRange(0.01, 1.0); self.dsb_vox.setValue(0.05); self.dsb_vox.setSuffix(" m")
        self.cb_writelas = QCheckBox("Also write per-plot LAS files")
        self.cb_writelas.setChecked(True)
        f.addRow("Canopy height cutoff:", self.dsb_hcut)
        f.addRow("Voxel size for volume:", self.dsb_vox)
        f.addRow("", self.cb_writelas)
        v.addWidget(params)

        # ---- Run + progress ----
        h2 = QHBoxLayout()
        self.btn_run = QPushButton("▶  Compute Traits")
        self.btn_run.clicked.connect(self._run)
        h2.addWidget(self.btn_run); h2.addStretch()
        v.addLayout(h2)

        self.progress = QProgressBar(); self.progress.setTextVisible(True)
        v.addWidget(self.progress)

        self.log = QTextEdit(); self.log.setReadOnly(True)
        self.log.setMaximumHeight(140)
        v.addWidget(self.log)

    def _sel_all(self):
        for cb in self._checks.values(): cb.setChecked(True)
    def _desel_all(self):
        for cb in self._checks.values(): cb.setChecked(False)
    def _defaults(self):
        defaults = {"h_p95", "h_p99", "h_mean", "h_std", "cover_frac",
                    "vol_voxel", "lodging_angle", "roughness",
                    "n_points", "n_canopy"}
        for k, cb in self._checks.items():
            cb.setChecked(k in defaults)

    def _run(self):
        s = state()
        if not s.las_path or not os.path.exists(s.las_path):
            QMessageBox.warning(self, "No LAS", "Load a project on the Project tab first.")
            return
        grid_path = s.saved_grid if (s.saved_grid and os.path.exists(s.saved_grid)) else s.grid_path
        if not grid_path or not os.path.exists(grid_path):
            QMessageBox.warning(self, "No grid",
                "Save an aligned grid (Edit tab) or load one on the Project tab.")
            return
        selected = [k for k, cb in self._checks.items() if cb.isChecked()]
        if not selected:
            QMessageBox.warning(self, "Pick something", "Select at least one trait.")
            return

        # ensure output paths
        s.derive_default_paths()

        kw = dict(
            las_path=s.las_path, work_crs=s.work_crs, use_smrf=s.use_smrf,
            grid_path=grid_path, out_dir=s.out_dir, out_csv=s.out_csv,
            selected=selected, write_las=self.cb_writelas.isChecked(),
            h_cut=self.dsb_hcut.value(), vox=self.dsb_vox.value(),
        )
        self.btn_run.setEnabled(False)
        self.progress.setValue(0)
        self.log.clear()
        self._w = _ExtractWorker(kw)
        self._w.progress.connect(self._on_progress)
        self._w.done_ok.connect(self._on_done)
        self._w.error.connect(self._on_error)
        self._w.start()

    def _on_progress(self, p, msg):
        self.progress.setValue(p)
        self.progress.setFormat(f"{p}% — {msg}")
        self.log.append(f"[{p:3d}%] {msg}")

    def _on_done(self, r):
        self.btn_run.setEnabled(True)
        self.log.append("\n--- DONE ---")
        self.log.append(f"CSV : {r['out_csv']}")
        self.log.append(f"LAS dir: {r['out_dir']}")
        self.log.append(f"Plots with points: {r['non']}/{r['total']}")
        self.log.append(f"Empty plots      : {r['empty']}")
        self.log.append(f"Median pts/plot  : {r['median_pts']:,}")
        QMessageBox.information(self, "Complete",
            f"Traits CSV written to:\n{r['out_csv']}\n\n"
            f"{r['non']}/{r['total']} plots had points "
            f"(median {r['median_pts']:,} pts/plot).\n\n"
            "Switch to the Statistics tab to visualize.")

    def _on_error(self, err):
        self.btn_run.setEnabled(True)
        self.log.append(f"\nERROR: {err}")
        QMessageBox.critical(self, "Failed", err)
